import "./styles.css";

/**
  Write the addheadings() function here
*/

/**
  Write the styleTutorialsAndArticles() function here
*/

/**
  Write the separateAllTutorials() function here
*/

/**
  No need to edit the following
*/
function main() {
  addHeadings();
  styleTutorialsAndArticles();
  separateAllTutorials();
}

main();
